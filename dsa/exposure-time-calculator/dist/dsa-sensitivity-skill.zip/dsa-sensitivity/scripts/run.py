#!/usr/bin/env python3
"""Run the DSA sensitivity calculator from the skill folder.  python3 scripts/run.py --help"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dsa_etc.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
